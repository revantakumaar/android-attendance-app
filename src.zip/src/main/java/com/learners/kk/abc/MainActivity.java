package com.learners.kk.abc;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity {

    EditText uname,pswd;
    Button login;
    public static DbHandler db;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        uname=(EditText)findViewById(R.id.uname);
        pswd=(EditText)findViewById(R.id.password);
        login=(Button)findViewById(R.id.login);
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                String name=uname.getText().toString();
                String password=pswd.getText().toString();

                int id= checkUser(new User(name,password));
                if(id==-1){
                    Toast.makeText(MainActivity.this,"User Does Not Exist", Toast.LENGTH_SHORT).show();
                }

               else if(id<55)
                {

                    Intent launchIntent = new Intent(MainActivity.this,prof.class);
                    startActivity(launchIntent);
                    Toast.makeText(MainActivity.this,"Student exist", Toast.LENGTH_SHORT).show();

                }
                else
                {
                    Intent launchIntent = new Intent(MainActivity.this,AppBase.class);
                    startActivity(launchIntent);
                    Toast.makeText(MainActivity.this,"exist "+name, Toast.LENGTH_SHORT).show();
                }


            }
        });

        db=new DbHandler(MainActivity.this);
//inserting dummy users
        db.addUser(new User(99,"admin", "admin"));
        db.addUser(new User(98,"sita", "sita"));
        db.addUser(new User(97,"murali krishna", "murali"));
        db.addUser(new User(96,"srinu", "srinu"));
        db.addUser(new User(95,"sandhya rani", "sandhya"));
        db.addUser(new User(94,"kranthikiran", "kranthi"));
        db.addUser(new User(93,"jyoshna", "jyoshna"));
        db.addUser(new User(92,"satya prakash", "satya"));

        db.addUser(new User(1,"rafi", "1201"));
        db.addUser(new User(2,"supriya", "1202"));
        db.addUser(new User(3,"revanta", "1203"));
        db.addUser(new User(4,"yedukondalu", "1204"));
        db.addUser(new User(5,"jayapraksah", "1205"));
        db.addUser(new User(6,"shruti", "1206"));
        db.addUser(new User(7,"anand", "1207"));
        db.addUser(new User(8,"saranya", "1208"));
        db.addUser(new User(9,"aditya babu", "1210"));
        db.addUser(new User(10,"kiran kumar", "1211"));
        db.addUser(new User(11,"narishimha reddy", "1212"));
        db.addUser(new User(12,"meghana", "1213"));
        db.addUser(new User(13,"jyothsna kalimata", "1214"));
        db.addUser(new User(14,"preetham chandak", "1215"));
        db.addUser(new User(15,"sowmya", "1216"));
        db.addUser(new User(16,"kavya chinnari", "1217"));
        db.addUser(new User(17,"janshi", "1218"));
        db.addUser(new User(18,"aneela", "1219"));
        db.addUser(new User(19,"suraj", "1220"));
        db.addUser(new User(20,"saikumari", "1221"));
        db.addUser(new User(21,"viveka", "1222"));
        db.addUser(new User(22,"chandrashekar", "1223"));
        db.addUser(new User(23,"manikanta", "1224"));
        db.addUser(new User(24,"yogalakshmi", "1225"));
        db.addUser(new User(25,"saikrishna", "1226"));
        db.addUser(new User(26,"sampath", "1227"));
        db.addUser(new User(27,"radhika", "1228"));
        db.addUser(new User(28,"anusha", "1229"));
        db.addUser(new User(29,"uma", "1230"));
        db.addUser(new User(30,"sushma", "1231"));
        db.addUser(new User(31,"J.mounika", "1232"));
        db.addUser(new User(32,"sri uma", "1233"));
        db.addUser(new User(33,"J.divya", "1234"));
        db.addUser(new User(34,"harika", "1235"));
        db.addUser(new User(35,"sri nija", "1236"));
        db.addUser(new User(36,"sirisha", "1237"));
        db.addUser(new User(37,"sridevi", "1238"));
        db.addUser(new User(38,"kalla anusha", "1239"));
        db.addUser(new User(39,"havya", "1240"));
        db.addUser(new User(40,"malavika", "1242"));
        db.addUser(new User(41,"kavitha", "1243"));
        db.addUser(new User(42,"ramani", "1244"));
        db.addUser(new User(43,"mounika katta", "1245"));
        db.addUser(new User(44,"chiranjeevi", "1246"));
        db.addUser(new User(45,"sravya", "1248"));
        db.addUser(new User(46,"vishnupriya", "1249"));
        db.addUser(new User(47,"kolli divya", "1250"));
        db.addUser(new User(48,"vamsi", "1251"));
        db.addUser(new User(49,"shilpa", "1252"));
        db.addUser(new User(50,"amulya", "1253"));
        db.addUser(new User(51,"neeraj", "1254"));


    }

    public int checkUser(User user)
    {
        return db.checkUser(user);
    }


}
