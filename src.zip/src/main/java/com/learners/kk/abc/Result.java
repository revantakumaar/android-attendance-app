package com.learners.kk.abc;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class Result extends AppCompatActivity {

    databaseHandler handler = AppBase.handler;
    Activity Result = this;
    ListView listView;
    profile_adapter adapter;

    Activity activity = this;
    private View v;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_res);

        TextView textView = (TextView) findViewById(R.id.profileContentView);
        Button findButton = (Button) findViewById(R.id.buttonFind);


        assert findButton != null;
        findButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                find(v, 1);
            }
        });
        Button findButton2 = (Button) findViewById(R.id.buttonFind2);
        assert findButton2 != null;
        findButton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                find(v, 2);
            }
        });
        Button findButton3 = (Button) findViewById(R.id.buttonFind3);
        assert findButton3 != null;
        findButton3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                find(v, 3);
            }
        });
    }

    public void find(View view, int k) {
        String buffer = "";

        String qur = "SELECT regno FROM STUDENT";
        Cursor curso = handler.execQuery(qur);
        curso.moveToFirst();
        Log.d("Result",Integer.toString(curso.getCount()));
        Log.d("Result",curso.getString(0));
        TextView textView = (TextView) findViewById(R.id.profileContentView);
            while(!curso.isAfterLast())
            {
                Log.d("Result",curso.getString(0));
                String reg = curso.getString(0);
            String qu = "SELECT * FROM STUDENT WHERE regno = '" + reg.toUpperCase() + "'";
            String qc = "SELECT * FROM ATTENDANCE  WHERE register = '" + reg.toUpperCase() + "';";
            String qd = "SELECT * FROM ATTENDANCE WHERE register = '" + reg.toUpperCase() + "' AND isPresent = 1";
            Cursor cursor = handler.execQuery(qu);
            //Start Count Here

            float att = 0f;
            Cursor cur = handler.execQuery(qc);
            Cursor cur1 = handler.execQuery(qd);
            if (cur == null) {
                Log.d("profile", "cur null");
            }
            if (cur1 == null) {
                Log.d("profile", "cur1 null");
            }
            if (cur != null && cur1 != null) {
                cur.moveToFirst();
                cur1.moveToFirst();
                try {
                    att = ((float) cur1.getCount() / cur.getCount()) * 100;
                    if (att <= 0)
                        att = 0f;
                    Log.d("profile_activity", "Total = " + cur.getCount() + " avail = " + cur1.getCount() + " per " + att);
                } catch (Exception e) {
                    att = -1;
                }
            }


            if (cursor == null || cursor.getCount() == 0) {
                assert textView != null;
                textView.setText("No Data Available");
            } else {
                String attendance = "";
                if (att < 0) {
                    attendance = "Attendance Not Available";
                } else
                    attendance = " Attendance " + att + " %";
                cursor.moveToFirst();

                if (att <= 65&& k==1) {
                    buffer += " " + cursor.getString(0) + "\n";
                    buffer += " " + cursor.getString(1) + "\n";
                    buffer += " " + cursor.getString(2) + "\n";
                    buffer += " " + cursor.getString(3) + "\n";
                    buffer += " " + attendance + "\n....................\n";
                }
                if (att >65&& att<=75&& k==2) {
                    buffer += " " + cursor.getString(0) + "\n";
                    buffer += " " + cursor.getString(1) + "\n";
                    buffer += " " + cursor.getString(2) + "\n";
                    buffer += " " + cursor.getString(3) + "\n";
                    buffer += " " + attendance + "\n.....................\n";
                }
                if (att >75&& k==3) {
                    buffer += " " + cursor.getString(0) + "\n";
                    buffer += " " + cursor.getString(1) + "\n";
                    buffer += " " + cursor.getString(2) + "\n";
                    buffer += " " + cursor.getString(3) + "\n";
                    buffer += " " + attendance + "\n......................\n";
                }

            }
                curso.moveToNext();
        }

        textView.setText(buffer);

    }
}
